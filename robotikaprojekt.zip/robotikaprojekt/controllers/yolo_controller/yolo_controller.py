import cv2
import numpy as np
from controller import Robot
from ultralytics import YOLO

robot = Robot()
timestep = int(robot.getBasicTimeStep())
camera = robot.getDevice('camera')
camera.enable(timestep)
model = YOLO('yolov8n.pt')

while robot.step(timestep) != -1:
    w, h = camera.getWidth(), camera.getHeight()
    raw_image = camera.getImage()
    
    image_array = np.frombuffer(raw_image, np.uint8).reshape((h, w, 4))
    
    frame = cv2.cvtColor(image_array, cv2.COLOR_BGRA2RGB)

    results = model.predict(frame, conf=0.5, verbose=False)

    annotated_frame = results[0].plot()
    cv2.imshow("Robot View - AI Detection", annotated_frame)
    cv2.waitKey(1)
    for result in results[0].boxes:
        label = model.names[int(result.cls)]
        print(f"I see a: {label}")